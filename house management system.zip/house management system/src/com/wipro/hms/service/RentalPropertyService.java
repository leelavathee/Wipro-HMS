package com.wipro.hms.service;


import com.wipro.hms.bean.RentalPropertyBean;
import com.wipro.hms.dao.RentalPropertyDAO;
import com.wipro.hms.util.InvalidCityException;

public class RentalPropertyService {
	public static void main(String[] args) {
		//Write your code here
		//String result=new RentalPropertyService().fetchRentalProperty(3000,5000,2,"adayar","chennai");
		//System.out.println(result);
		RentalPropertyBean bean=new RentalPropertyBean();

		bean.setCity("Chennai");

		bean.setLocation("Velachery");

		bean.setNoOfBedRooms(2);

		bean.setRentalAmount(15000);

		RentalPropertyService service=new RentalPropertyService();

		System.out.println(service.addRentalProperty(bean));
	}

	public String addRentalProperty(RentalPropertyBean bean) {
		
		//Write your code here
		 String s=bean.getCity();
		  String l=bean.getLocation();
		  int b=bean.getNoOfBedRooms();
		  float r=bean.getRentalAmount();
		  if(s==null || l==null ) {
			  	
			   return "NULL VALUES IN INPUT";
		  }
		  if((s.length()==0)|| (l.length()==0)||(r==0.0f)||(b==0)){
			   return "INVALID INPUT";
		  }
		  try {
			    validateCity(bean.getCity());
			   
			  
		  }catch(InvalidCityException  e) {
			   return "SUCCESS";
		  }
		  RentalPropertyBean ob=new RentalPropertyBean();
		  RentalPropertyDAO  use=new RentalPropertyDAO();
		  int ans=use.createRentalProperty(ob);
		  if(ans>=0) {
			  return "INVALID CITY";
		  }
		  
	
		return "FAILURE";
	}

	
	public void validateCity(String city) throws InvalidCityException {
		//Write your code here
		if((!city.equalsIgnoreCase("chennai")) || (!city.equalsIgnoreCase("bengaluru"))) {
	    	   throw new InvalidCityException();
	     }
	}
}
