package com.wipro.hms.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

import com.wipro.hms.bean.RentalPropertyBean;
import com.wipro.hms.util.DBUtil;



public class RentalPropertyDAO {
	public String generatePropertyID(String city) {
		String id = "";
		//Write your code here
       
       try {
    	 Connection con=DBUtil.getDBConnection();
    	Statement s=con.createStatement();
		ResultSet r=s.executeQuery("select RENTAL_SEQ.nextval from dual");
		String temp="";
		while(r.next()) {
			temp=r.getString(1);
		}
		if(city.length()<3) {
			city=city.toUpperCase();
		}else {
			city=city.substring(0,3).toUpperCase();
		}
		
		id=city+temp;
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		return id;
	}

	public int createRentalProperty(RentalPropertyBean bean) {

		//Write your code here
		
		String prop=generatePropertyID(bean.getCity());
        bean.setPropertyId(prop);
       
        try {
       	Connection con=DBUtil.getDBConnection();
			PreparedStatement p=con.prepareStatement("insert into RENTAL_TBL values(?,?,?,?,?)");
			p.setFloat(1, bean.getRentalAmount());
			p.setInt(2, bean.getNoOfBedRooms());
			p.setString(3, bean.getLocation());
			p.setString(4,bean.getCity());
			p.setString(5, bean.getPropertyId());
			boolean ans=p.execute();
			if(!ans) {
				 return 1;
			}
		    
		} catch (Exception e) {
			// TODO Auto-generated catch block
		    
			//e.printStackTrace();
		}
        
        
		return -1;
	}

	
}
