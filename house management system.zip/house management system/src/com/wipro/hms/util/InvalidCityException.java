package com.wipro.hms.util;

public class InvalidCityException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString() {
		//Write your code here
		return "INVALID CITY";
	}
}
